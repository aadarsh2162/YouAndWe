package com.youandwe.appsecurity.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.youandwe.appsecurity.config.service.JWTService;
import com.youandwe.appsecurity.config.service.MyUserDetailsService;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

	@Autowired
	private JWTService jwtService;

	@Autowired
	private MyUserDetailsService detailsService;
	@Autowired
	ApplicationContext context;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		
		  String path = request.getRequestURI();
	       
		  if (path.startsWith("/api/auth/login") || path.startsWith("/api/auth/signup")) {
		        filterChain.doFilter(request, response);
		        return;  // Continue request processing
		    }
		  
		  
		String authHeader = request.getHeader("Authorization");
		System.out.println("test");
		
		System.out.println(authHeader + "auth header in filter");
		String token = null;
		String username = null;

		if (authHeader != null && authHeader.startsWith("Bearer ")) {
			System.out.println("if statemnt excuted in jwt filter");
			token = authHeader.substring(7);
			System.out.println("token extract except bearer" + token);
			username = jwtService.extractUserName(token);
			
			System.out.println("Extracted Username/Email from Token: " + username);
		}

		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

			UserDetails userDetails = detailsService.loadUserByUsername(username);
			System.out.println("User found: " + userDetails.getUsername());
		    System.out.println("User Roles: " + userDetails.getAuthorities());
			if (jwtService.validateToken(token, userDetails)) {
				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
				null, userDetails.getAuthorities());
				System.out.println(authToken + "auth token for verification ");
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
		}

		filterChain.doFilter(request, response);
	}
}