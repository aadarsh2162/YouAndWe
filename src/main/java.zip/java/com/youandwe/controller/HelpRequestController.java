package com.youandwe.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.youandwe.entity.HelpRequest;
import com.youandwe.service.interfaces.HelpRequestInter;

@RestController
@RequestMapping("/api/helpRequests")
public class HelpRequestController {

	@Autowired
	private HelpRequestInter helpRequestService;

	@PreAuthorize("hasAnyRole('ADMIN', 'USER')")
	@PostMapping
	public ResponseEntity<HelpRequest> saveRequest(@RequestBody HelpRequest request) {
		return ResponseEntity.ok().body(helpRequestService.saveRequest(request));
	}

	@PreAuthorize("hasAnyRole('ADMIN', 'USER')")
	@GetMapping
	public ResponseEntity<Iterable<HelpRequest>> getAllRequest() {
		return ResponseEntity.ok(helpRequestService.getAllRequest());
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteRequestById(@PathVariable Integer id) {
		return ResponseEntity.accepted().body(helpRequestService.deleteById(id));
	}

	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("admin")
	public String admin() {
		return "welcome Admin";
	}


	
	
	
	@PreAuthorize("hasAuthority('ADMIN'))")
	@PutMapping("/{id}")
	public ResponseEntity<HelpRequest> updateTodo(@RequestBody HelpRequest helpRequestDto, @PathVariable("id") Long helpRequestId) {
		HelpRequest updatedHelpRequest = helpRequestService.updateHelpRequest(helpRequestDto, helpRequestId);
		return ResponseEntity.ok(updatedHelpRequest);
	}

}
