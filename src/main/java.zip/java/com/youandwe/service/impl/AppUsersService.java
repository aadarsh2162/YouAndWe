package com.youandwe.service.impl;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.youandwe.appsecurity.config.service.JWTService;
import com.youandwe.appsecurity.config.service.MyUserDetailsService;
import com.youandwe.appsecurity.config.service.UserPrincipal;
import com.youandwe.daos.JwtAuthResponse;
import com.youandwe.daos.LoginRequestDAO;
import com.youandwe.entity.AppUsers;
import com.youandwe.entity.Role;
import com.youandwe.repository.AppUsersRepository;
import com.youandwe.repository.RoleRepository;
import com.youandwe.service.interfaces.UserAuth;

import youandme.exceptions.HelpRequestAPIException;
import youandme.exceptions.InvalidCredentials;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

@Service
public class AppUsersService implements UserAuth {
	@Autowired
	private JWTService jwtService;

	@Autowired
	AuthenticationManager authManager;

	@Autowired
	private AppUsersRepository repo;

	@Autowired
	MyUserDetailsService detailsService;

	@Autowired
	private RoleRepository roleRepository;

	private BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

	@Override
	public AppUsers register(AppUsers user) {
		// check username is already exists in database
		if (repo.existsByUsername(user.getUsername())) {
			throw new HelpRequestAPIException(HttpStatus.BAD_REQUEST, "Username already exists!");
		}

		// check email is already exists in database
		if (repo.existsByEmail(user.getEmail())) {
			throw new HelpRequestAPIException(HttpStatus.BAD_REQUEST, "Email is already exists!.");
		}

		AppUsers userCred = new AppUsers();
		userCred.setName(user.getName());
		userCred.setUsername(user.getUsername());
		userCred.setEmail(user.getEmail());
		userCred.setPassword(encoder.encode(user.getPassword()));
		userCred.setSignupTime(LocalDateTime.now());

		user.setPassword(encoder.encode(user.getPassword()));
		user.setSignupTime(LocalDateTime.now());

		Set<Role> roles = new HashSet<>();
		Role userRole = roleRepository.findByName("ROLE_USER");
		System.out.println(userRole.getName());

		roles.add(userRole);

		user.setRoles(roles);
		return repo.save(user);

	}

	/*
	 * @Override public JwtAuthResponse verify(LoginRequestDAO loginRequestDAO) {
	 * String identifier = loginRequestDAO.getUsernameOrEmail(); // Extract
	 * username/email String password = loginRequestDAO.getPassword(); // Extract
	 * password
	 * 
	 * // Authenticate user Authentication authentication = authManager
	 * .authenticate(new UsernamePasswordAuthenticationToken(identifier, password));
	 * 
	 * SecurityContextHolder.getContext().setAuthentication(authentication); if
	 * (!authentication.isAuthenticated()) { throw new
	 * InvalidCredentials("Invalid Username or Password"); }
	 * 
	 * // Fetch user details AppUsers loggedInUser =
	 * repo.findByUsernameOrEmail(identifier, identifier) .orElseThrow(() -> new
	 * InvalidCredentials("User not found"));
	 * 
	 * // Extract roles Set<String> roleNames =
	 * loggedInUser.getRoles().stream().map(Role::getName).collect(Collectors.toSet(
	 * ));
	 * 
	 * // Generate JWT token String token = jwtService.generateToken(identifier); //
	 * Prepare response JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
	 * jwtAuthResponse.setRole(roleNames); jwtAuthResponse.setAccessToken(token);
	 * 
	 * return jwtAuthResponse; }
	 */

	  @Override
	    public JwtAuthResponse verify(LoginRequestDAO loginRequestDAO) {
	        Authentication authentication = authManager.authenticate(
	            new UsernamePasswordAuthenticationToken(
	                loginRequestDAO.getUsernameOrEmail(),
	                loginRequestDAO.getPassword()
	            )
	        );
	        
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
	        
	        String token = jwtService.generateToken(userPrincipal);
	        Set<String> roles = userPrincipal.getAuthorities().stream()
	                .map(GrantedAuthority::getAuthority)
	                .collect(Collectors.toSet());
	        
	        return new JwtAuthResponse(token, "Bearer", roles);
	    }
	@Override
	public Long countUser() {
		return repo.count();
	}

}
